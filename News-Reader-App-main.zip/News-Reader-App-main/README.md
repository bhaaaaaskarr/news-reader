# News-Reader-App
**This very simple python project is built focusing on the requests module**
<br>
What this app does is that this app takes latest news from [NewsAPI](newsapi.org) and reads it out loud to you. 
### Notice - The speaking function only works for windows. For mac or linux there are different ways to make your program speak which you have to find out

## Complete Video Tutorial :-
<table>
<tr><td><a href="https://www.youtube.com/watch?v=7a5LsPz9jOs"><img width="140px" src="https://i.ytimg.com/vi/7a5LsPz9jOs/maxresdefault.jpg"></a></td>
<td><a href="https://www.youtube.com/watch?v=7a5LsPz9jOs">Beginner Python Project - News Narration App using Requests Module</a><br/></td></tr>
</table>
